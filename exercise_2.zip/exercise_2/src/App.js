import React from 'react';
import Home from './Home.js';
import './App.css';

function App() {

  let profession =  [
    {
      name:'Design',
      subname: ['+Product Markup','+Branding','+Ilustrattions','+UI/UX','+Websites']
    },
    {
      name:'Web Design',
      subname: ['+Propotype','+UI/UX','+Content writing', '+Website hosting','+Website analysis']
    },
    {
      name:'Development',
      subname: ['+Wordpess','+Aplication Development','+Front-end','+PHP','+Javascript']
    },
    {
      name:'Branding',
      subname: ['+Brand equity audit','+Audience analysis','+Compotetive reviews', '+Strategic direction','+Visual positioning']
    },
    {
      name:'Marketing',
      subname: ['+SEO Marketing','+SE optimization','+Affiliate marketing','+Keyword','+Article writing']
    },
    {
      name:'Video Editing',
      subname: ['+Animation','+MotionGraphics','+After Effects','+Cinema 4D','+After effects']
      
      }
   ] ;


  return (
  <>
<div className='div'>
    <h1>Design and Development</h1>
    <p>Lorem Ipsum is simply dummy text of the printing and </p>
      <p> typesetting industry.</p>
    </div>

    <div className="App">
    
    {profession.map((item,i)=>{
      return (
      <Home
        key={i}
      name = {item.name}
      subname={item.subname}
      
              
       /> )}
      
      )}
      
     
     </div>
    
     </>
  );
}

export default App;
