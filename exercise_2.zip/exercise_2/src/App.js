import Home from './Home.js';
import './App.css';

function App() {

  let profession =  [
    {
      name:'Design',
      subname1:'+Product Markup',
      subname2:'+Branding',
      subname3:'+Ilustrattions',
      subname4:'+UI/UX',
      subname5:'+Websites',
    },
    {
      name:'Web Design',
      subname1:'+Propotype',
      subname2:'+UI/UX',
      subname3:'+Content writing',
      subname4:'+Website hosting',
      subname5:'+Website analysis'
    },
    {
      name:'Development',
      subname1:'+Wordpess',
      subname2:'+Aplication Development',
      subname3:'+Front-end',
      subname4:'+PHP',
      subname5:'+Javascript'
    },
    {
      name:'Branding',
      subname1:'+Brand equity audit',
      subname2:'+Audience analysis',
      subname3:'+Compotetive reviews',
      subname4:'+Strategic direction',
      subname5:'+Visual positioning'
    },
    {
      name:'Marketing',
      subname1:'+SEO Marketing',
      subname2:'+SE optimization',
      subname3:'+Affiliate marketing',
      subname4:'+Keyword',
      subname5:'+Article writing'
    },
    {
      name:'Video Editing',
      subname1:'+Animation',
      subname2:'+MotionGraphics',
      subname3:'+After Effects',
      subname4:'+Cinema 4D',
      subname5:'+After effects'
      
      }
   ] ;


  return (
  <>
<div className='div'>
    <h1>Design and Development</h1>
    <p>Lorem Ipsum is simply dummy text of the printing and </p>
      <p> typesetting industry.</p>
    </div>

    <div className="App">
    
    {profession.map((item)=>{
      return (
      <Home
        name = {item.name}
      subname1={item.subname1}
      subname2= {item.subname2}
      subname3={item.subname3}
      subname4={item.subname4}
      subname5= {item.subname5}
              
       /> )}
      
      )}
      
     
     </div>
    
     </>
  );
}

export default App;
