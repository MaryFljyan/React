import React from 'react';
import App from './App.js'

function Home({name,subname}){
    return (
        <div>
            <h3 className='title'> {name}</h3>
            <p className='text'> {subname}</p>
            {subname.map((item,i)=>{
                return (
                    <p key = {i} className='index'> {item}</p>
                )
                })}
            <App/>
        </div>
    )
}


export default Home;