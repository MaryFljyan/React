function Home({name,subname1,subname2,subname3,subname4,subname5}){
    return (
        <div>
            <h3 className='title'> {name}</h3>
            <div className='text'>
            <p> {subname1}</p>
            <p> {subname2}</p>
            <p> {subname3}</p>
            <p> {subname4}</p>
            <p> {subname5}</p>
            </div>
        </div>
    )
}


export default Home;