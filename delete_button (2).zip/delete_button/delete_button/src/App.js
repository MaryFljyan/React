import { useState } from 'react';
import './App.css';
import Home from './Home.js';
import img1 from './Images/user.jpg';

function App() {
  let people = [
    {
      id: 1,
      text:'A bracket is either of two tall fore- or back-facing punctuation marks commonly used to isolate a segment of text or data from its surroundings. ',
      name:'Mary',
      img:img1,
      profession:'Engineer'

    },
    {
      id: 2,
      text:'A bracket is either of two tall fore- or back-facing punctuation marks commonly used to isolate a segment of text or data from its surroundings. ',
      name:'Joe',
      img:img1,
      profession:'Engineer'
    },
    {
      id: 3,
      text:'A bracket is either of two tall fore- or back-facing punctuation marks commonly used to isolate a segment of text or data from its surroundings. ',
      name:'Jane',
      img:img1,
      profession:'Engineer'
    }
] 


const[value,setValue] =  useState(people); 

  return (
 <>
 
  <button className="button" onClick={() => {
  setValue([...value,{
       id: 4,
       text:'A bracket is either of two tall fore- or back-facing punctuation marks commonly used to isolate a segment of text or data from its surroundings. ',
       name:'Julia',
       img:img1,
       profession:'Engineer'
 
     }])
   }}>
   Add </button>
    <div className='div1'>
      <h1> What do our users say?</h1>
    </div>
    
    <div className="App">
        
    {value.map((item,i)=> {
    return (
    <Home 
      key ={i}
      text = {item.text}
        img = {item.img} 
        id={item.id}
        name = {item.name} 
        profession = {item.profession}
        func = {(id) => {
          setValue(value.filter(item => item.id !== id))
        }}
        />
        
    )})}
    
      
       </div>


      

    </>
  );
}

export default App;
