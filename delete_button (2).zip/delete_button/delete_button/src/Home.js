function Home({text,name,img,profession,func, id}){
    return(
   
        <div className='div'>  
            <p>{text}</p>
            <img className = 'img' src = {img} />
            <p className='p2'>{name}</p>
            <p>{profession}</p>
            <button 
             onClick={() =>
                func(id)}> Delete </button>
   
     </div>
     
     
    );
    

}


export default Home;