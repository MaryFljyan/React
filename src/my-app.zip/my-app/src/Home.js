function Home({text,name,img,profession}){
    return(
   
        <div className='div'>  
            <p>{text}</p> <img className = 'img' src = {img} />
            <p className='p2'>{name}</p>
            <p>{profession}</p>
    
     </div>
     
    )

}


export default Home;