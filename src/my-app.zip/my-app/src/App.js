
import './App.css';
import Home from './Home.js';
import img1 from './Images/user.jpg'

function App() {
  let people = [
    {
      text:'A bracket is either of two tall fore- or back-facing punctuation marks commonly used to isolate a segment of text or data from its surroundings. ',
      name:'Mary',
      img:img1,
      profession:'Engineer'

    },
    {
      text:'A bracket is either of two tall fore- or back-facing punctuation marks commonly used to isolate a segment of text or data from its surroundings. ',
      name:'Joe',
      img:img1,
      profession:'Engineer'
    },
    {
      text:'A bracket is either of two tall fore- or back-facing punctuation marks commonly used to isolate a segment of text or data from its surroundings. ',
      name:'Jane',
      img:img1,
      profession:'Engineer'
    }
] 

  return (
    <>
    <div class='div1'>
      <h1> What do our users say?</h1>
    </div>
    
    <div className="App">
       {people.map((item)=> {
            return (
            <Home text = {item.text}
                img = {item.img} 
                name = {item.name} 
                profession = {item.profession}/>
            )


       })}
    <Home/>
    </div>
    </>
  );
}

export default App;
